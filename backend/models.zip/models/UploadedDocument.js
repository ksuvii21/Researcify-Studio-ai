const mongoose= require('mongoose'); //Written by myself but updated with Gemini

/*
 * A document is a file the user uploaded.
 *
 * The bytes live on disk (see config/documentUpload.js);
 * this collection stores only metadata, ownership,
 * relationships and processing state.
 */
const uploadedDocumentSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true,
        index: true, // Index for faster queries
    },
    /*
     * Canonical project relationship for documents.
     *
     * A document belongs to at most one project, so it
     * is stored here rather than in
     * ResearchProject.documentIds. That array is kept
     * for compatibility but is no longer written to.
     */
    projectId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'ResearchProject',
        default: null,
        index: true, // Index for faster queries
    },
    title: {
        type: String,
        required: true,
        trim: true,
    },
    description: {
        type: String,
        default: '',
        trim: true,
    },
    originalFileName: {
        type: String,
        required: true,
    },
    /*
     * Server-generated filename. Never derived from the
     * user-supplied name, so a malicious upload cannot
     * influence the path on disk.
     */
    storedName: {
        type: String,
        default: '',
    },
    mimeType: {
        type: String,
        default: '',
    },
    /*
     * API route that serves the file to its owner:
     *   GET /api/v1/documents/:id/download
     *
     * It is derived from the generated _id, so it is set
     * by createDocument after the record exists and is not
     * required at creation time. Storage adapters that
     * move to object storage can remap this without
     * touching the rest of the pipeline.
     */
    fileUrl: {
        type: String,
        default: "",
    },
    /*
     * Absolute path on disk. Used for deletion and, in
     * 8D.5, for streaming the file back to its owner.
     */
    storagePath: {
        type: String,
        default: '',
    },
    fileSize: {
        type: Number,
        required: true,
    },
    pageCount: {
        type: Number,
        default: 0,
    },
    extractedText: {
        type: String,
        default: '',
    },
    /*
     * 'Processing' and 'Completed' are retained because
     * the model already used them. 8G will drive these
     * transitions once extraction and chunking exist.
     */
    processingStatus: {
        type: String,
        enum: ['Pending', 'Processing', 'Completed', 'Failed'],
        default: 'Pending',
    },
    processingError: {
        type: String,
        default: '',
    },
    extractedTextAvailable: {
        type: Boolean,
        default: false,
    },
    chunkCount: {
        type: Number,
        default: 0,
    },
    aiSummary: {
        type: String,
        default: '',
    },

},
{
    timestamps: {createdAt: 'uploadedAt', updatedAt: 'updatedAt'}, // Automatically adds uploadedAt and updatedAt fields
});

uploadedDocumentSchema.index({ userId: 1, updatedAt: -1 });
uploadedDocumentSchema.index({ userId: 1, projectId: 1 });

module.exports = mongoose.model('UploadedDocument', uploadedDocumentSchema);